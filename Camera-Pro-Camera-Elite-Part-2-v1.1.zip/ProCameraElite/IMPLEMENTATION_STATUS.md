# Implementation status

## Included and wired
- [x] Native Android app named Camera; no WebView.
- [x] CameraX live preview opens as the launch screen after camera permission.
- [x] Front/back camera switching.
- [x] Tap-to-focus and AE metering.
- [x] Pinch-to-zoom through CameraControl.
- [x] Flash auto/on/off for still capture; torch for continuous on.
- [x] Still capture at camera-selected maximum by default.
- [x] JPEG output-size list from Camera2 characteristics; user can select an advertised still size, including 4K/2K-class sizes when the sensor exposes them.
- [x] Pro Camera Elite lower-right watermark on saved still photos.
- [x] Video recording with optional audio and MediaStore output.
- [x] CameraX video quality choices (UHD/FHD/HD/SD) limited to qualities reported by active camera.
- [x] Camera2 AE FPS range discovery and user-selectable standard values with unsupported-value warning.
- [x] Gallery hand-off.
- [x] GitHub Actions debug build workflow.

## Known gaps; do not advertise as complete
- [ ] Live Photo motion-photo container / paired media workflow.
- [ ] Guaranteed exact 2K video output. CameraX standard quality tiers do not expose a generic 1440p tier.
- [ ] FPS-by-resolution capability matrix and verification of encoded output metadata on each physical device.
- [ ] True OEM Night/Bokeh/HDR/Face Retouch extensions and computational scene processing.
- [ ] Dedicated Food, Super Moon, Underwater, Forest, Supernova, Portrait and Night image pipelines; current scene strip is not a finished image-processing engine.
- [ ] Full manual ISO, shutter, white balance and manual focus-distance controls.
- [ ] RAW/DNG capture, QR scanning, video stabilization/HDR/slow-motion/time-lapse and video watermarking.
- [ ] Full in-app gallery browser and settings persistence.

This status file is intentionally explicit so future development does not confuse a visible selector with a working imaging pipeline.
