# Camera Pro Elite — implementation status

## Updated in this source revision
- [x] Main camera tabs are PHOTO, PORTRAIT, VIDEO and PRO; extra looks are moved into the MODE selector.
- [x] Resolution, photo-size and FPS controls are hidden in a compact three-dot menu and animated when opened/closed.
- [x] Mode-tab selection, shutter press and front/back camera switching have UI animations.
- [x] A shutter click sound and haptic confirmation are played after a successful still capture (subject to device/system camera-sound policy).
- [x] FOOD, FOREST, NIGHT fallback, SUPER MOON, UNDERWATER, SUPERNOVA, MONO and SEPIA apply actual pixel colour processing to the saved photo; they are not just labels.
- [x] PORTRAIT attempts to use the CameraX BOKEH extension when the device advertises it. If unavailable, the fallback is a portrait colour treatment only; it does not create subject-aware background blur.
- [x] NIGHT attempts to use the CameraX NIGHT extension when available. The fallback brightens/tunes the captured JPEG; it is not multi-frame computational night photography.
- [x] PRO includes real camera exposure-compensation control, tap-to-focus/AE metering and pinch zoom. Manual ISO, shutter time, white balance and focus distance are not yet exposed.
- [x] Existing CameraX photo capture, video recording, advertised photo-size list, supported video quality list and FPS selection are retained.

## Known limitations (do not advertise as completed)
- [ ] Portrait depth segmentation / edge-aware bokeh on devices without a supported CameraX BOKEH extension.
- [ ] Multi-frame computational Night mode on devices without a supported CameraX NIGHT extension.
- [ ] Manual ISO, shutter speed, white balance and focus-distance controls.
- [ ] True optical zoom/lens switching beyond what the device exposes through CameraX.
- [ ] Slow motion and time-lapse recording pipelines; they are intentionally not shown as working modes in this revision.
- [ ] Full in-app gallery browser; the current gallery control still hands off to the phone's gallery app.
- [ ] Live Photo motion-photo container / paired media workflow.
- [ ] Full FPS-by-resolution capability matrix and verification of encoded output metadata on each physical device.
- [ ] Local build and device testing were not possible in this environment because the Gradle distribution download was blocked by unavailable network DNS. Run the included GitHub Actions workflow to compile and test on CI.

This status file distinguishes real capture processing from device-specific extensions and from features that remain unfinished.
