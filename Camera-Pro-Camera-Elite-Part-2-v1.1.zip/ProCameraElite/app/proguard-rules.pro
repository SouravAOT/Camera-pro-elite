# Keep CameraX metadata and application model classes if shrinking is enabled later.
