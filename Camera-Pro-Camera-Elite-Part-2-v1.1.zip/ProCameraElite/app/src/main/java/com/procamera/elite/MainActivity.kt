package com.procamera.elite

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.media.MediaActionSound
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import android.app.AlertDialog
import androidx.activity.ComponentActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var resolutionButton: TextView
    private lateinit var photoResolutionButton: TextView
    private lateinit var fpsButton: TextView
    private lateinit var flashButton: TextView
    private lateinit var shutter: ImageButton
    private lateinit var modeStrip: LinearLayout
    private lateinit var settingsPanel: LinearLayout
    private lateinit var modeButton: TextView
    private val shutterSound by lazy { MediaActionSound().apply { load(MediaActionSound.SHUTTER_CLICK) } }
    private var extensionActive = false
    private lateinit var cameraExecutor: ExecutorService
    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var flashMode = ImageCapture.FLASH_MODE_AUTO
    private var selectedQuality = Quality.FHD
    private var selectedFps = 30
    private var supportedFps = listOf(30)
    private var supportedQualities = listOf(Quality.SD, Quality.HD, Quality.FHD)
    private var photoSizes: List<Size> = emptyList()
    private var selectedPhotoSize: Size? = null
    private var currentMode = "PHOTO"
    private var selectedScene = "AUTO"
    private var cameraReady = false

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val granted = result[Manifest.permission.CAMERA] == true
        if (granted) startCamera() else showStatus("Camera permission is required to use Camera")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        setContentView(R.layout.main)
        cameraExecutor = Executors.newSingleThreadExecutor()
        previewView = findViewById(R.id.viewFinder)
        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
        status = findViewById(R.id.statusText)
        resolutionButton = findViewById(R.id.resolutionButton)
        photoResolutionButton = findViewById(R.id.photoResolutionButton)
        fpsButton = findViewById(R.id.fpsButton)
        flashButton = findViewById(R.id.flashButton)
        shutter = findViewById(R.id.shutterButton)
        modeStrip = findViewById(R.id.modeStrip)
        settingsPanel = findViewById(R.id.settingsPanel)
        modeButton = findViewById(R.id.modeButton)
        setupControls()
        val permissions = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT <= 32) permissions.add(Manifest.permission.RECORD_AUDIO)
        else permissions.add(Manifest.permission.RECORD_AUDIO)
        if (permissions.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) startCamera()
        else permissionLauncher.launch(permissions.toTypedArray())
    }

    private fun setupControls() {
        findViewById<TextView>(R.id.flashButton).setOnClickListener {
            flashMode = when (flashMode) {
                ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_OFF
                else -> ImageCapture.FLASH_MODE_AUTO
            }
            imageCapture?.flashMode = flashMode
            camera?.cameraControl?.enableTorch(flashMode == ImageCapture.FLASH_MODE_ON)
            flashButton.text = when (flashMode) { ImageCapture.FLASH_MODE_ON -> "⚡ ON"; ImageCapture.FLASH_MODE_OFF -> "⚡ OFF"; else -> "⚡ AUTO" }
        }
        resolutionButton.setOnClickListener { showQualityPicker() }
        photoResolutionButton.setOnClickListener { showPhotoSizePicker() }
        fpsButton.setOnClickListener { showFpsPicker() }
        findViewById<TextView>(R.id.settingsButton).setOnClickListener { toggleSettingsPanel() }
        findViewById<TextView>(R.id.advancedSettingsButton).setOnClickListener { showSettings() }
        modeButton.setOnClickListener {
            modeButton.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).withEndAction {
                modeButton.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }.start()
            showExtraModes()
        }
        findViewById<ImageButton>(R.id.switchButton).setOnClickListener {
            if (recording != null) { showStatus("Stop recording before switching camera"); return@setOnClickListener }
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            findViewById<ImageButton>(R.id.switchButton).animate().rotationY(180f).setDuration(260).withEndAction {
                findViewById<ImageButton>(R.id.switchButton).rotationY = 0f
            }.start()
            previewView.animate().alpha(0.45f).setDuration(110).withEndAction {
                startCamera()
                previewView.animate().alpha(1f).setDuration(220).start()
            }.start()
        }
        findViewById<ImageButton>(R.id.galleryButton).setOnClickListener { openGallery() }
        shutter.setOnClickListener { if (currentMode == "VIDEO") toggleVideo() else takePhoto() }
        modeStrip.removeAllViews()
        listOf("PHOTO", "PORTRAIT", "VIDEO", "PRO").forEach { mode ->
            val item = TextView(this).apply {
                text = mode
                textSize = 11f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(if (mode == currentMode) 0xFF62AFFF.toInt() else 0xFFFFFFFF.toInt())
                setPadding(12, 8, 12, 8)
                gravity = Gravity.CENTER
                setOnClickListener { setMode(mode) }
            }
            modeStrip.addView(item)
        }
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val state = camera?.cameraInfo?.zoomState?.value ?: return false
                val next = (state.zoomRatio * detector.scaleFactor).coerceIn(state.minZoomRatio, state.maxZoomRatio)
                camera?.cameraControl?.setZoomRatio(next)
                return true
            }
        })
        previewView.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f; private var downY = 0f; private var multiTouch = false
            override fun onTouch(v: View, e: android.view.MotionEvent): Boolean {
                scaleDetector.onTouchEvent(e)
                when (e.actionMasked) {
                    android.view.MotionEvent.ACTION_POINTER_DOWN -> multiTouch = true
                    android.view.MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; multiTouch = false }
                    android.view.MotionEvent.ACTION_UP -> {
                        if (!multiTouch) {
                            val point = previewView.meteringPointFactory.createPoint(e.x, e.y)
                            val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE).setAutoCancelDuration(3, TimeUnit.SECONDS).build()
                            camera?.cameraControl?.startFocusAndMetering(action)
                            showStatus("Focus / exposure adjusted")
                        }
                    }
                }
                return true
            }
        })
    }

    private fun setMode(mode: String) {
        if (recording != null) { showStatus("Stop recording before changing mode"); return }
        currentMode = mode
        selectedScene = if (mode == "PORTRAIT") "PORTRAIT" else "AUTO"
        for (i in 0 until modeStrip.childCount) {
            val tab = modeStrip.getChildAt(i) as TextView
            val selected = tab.text.toString() == mode
            tab.setTextColor(if (selected) 0xFF62AFFF.toInt() else 0xFFFFFFFF.toInt())
            tab.animate().scaleX(if (selected) 1.08f else 1f).scaleY(if (selected) 1.08f else 1f)
                .setDuration(180).start()
        }
        shutter.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).withEndAction {
            shutter.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
        }.start()
        shutter.setImageResource(if (mode == "VIDEO") android.R.drawable.presence_video_online else R.drawable.shutter_core)
        if (mode == "PORTRAIT") {
            showStatus("Portrait · checking supported camera bokeh effect")
            startCamera()
        } else {
            if (extensionActive) startCamera() else showStatus(when (mode) {
                "VIDEO" -> "Video · ${qualityLabel(selectedQuality)} · ${selectedFps} FPS"
                "PRO" -> "Pro · tap to focus, exposure metering and manual zoom available"
                else -> "Photo · full sensor resolution"
            })
        }
    }

    private fun toggleSettingsPanel() {
        val opening = settingsPanel.visibility != View.VISIBLE
        if (opening) {
            settingsPanel.alpha = 0f
            settingsPanel.translationY = -12f
            settingsPanel.visibility = View.VISIBLE
            settingsPanel.animate().alpha(1f).translationY(0f).setDuration(220).start()
            findViewById<TextView>(R.id.settingsButton).animate().rotation(90f).setDuration(180).start()
        } else {
            settingsPanel.animate().alpha(0f).translationY(-12f).setDuration(180).withEndAction {
                settingsPanel.visibility = View.GONE
                settingsPanel.alpha = 1f
                settingsPanel.translationY = 0f
            }.start()
            findViewById<TextView>(R.id.settingsButton).animate().rotation(0f).setDuration(180).start()
        }
    }

    private fun showExtraModes() {
        val modes = arrayOf("AUTO · Original camera output", "FOOD · Warm colour and saturation", "NIGHT · Low-light enhancement", "FOREST · Green/nature colour", "SUPER MOON · Contrast and detail", "UNDERWATER · Blue/green correction", "SUPERNOVA · Vivid colour", "MONO · Black and white", "SEPIA · Warm vintage")
        AlertDialog.Builder(this).setTitle("Extra camera modes")
            .setSingleChoiceItems(modes, modes.indexOfFirst { it.startsWith(selectedScene) }.coerceAtLeast(0)) { dialog, which ->
                val scene = modes[which].substringBefore(" ·")
                selectedScene = scene
                if (scene == "AUTO") currentMode = "PHOTO"
                else currentMode = "PHOTO"
                for (i in 0 until modeStrip.childCount) {
                    val tab = modeStrip.getChildAt(i) as TextView
                    tab.setTextColor(if (tab.text.toString() == "PHOTO") 0xFF62AFFF.toInt() else 0xFFFFFFFF.toInt())
                }
                modeButton.animate().rotationX(360f).setDuration(280).withEndAction { modeButton.rotationX = 0f }.start()
                showStatus(if (scene == "NIGHT") "Night mode · native night extension when supported, otherwise low-light image tuning" else "$scene mode selected · image processing will be applied to captured photo")
                dialog.dismiss()
                if (extensionActive || scene == "NIGHT") startCamera()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                provider = future.get()
                val p = provider ?: return@addListener
                val baseSelector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
                var selector = baseSelector
                extensionActive = false
                val wantedExtension = when (selectedScene) {
                    "PORTRAIT" -> ExtensionMode.BOKEH
                    "NIGHT" -> ExtensionMode.NIGHT
                    else -> null
                }
                if (wantedExtension != null) {
                    try {
                        val manager = ExtensionsManager.getInstanceAsync(this, p).get()
                        if (manager.isExtensionAvailable(baseSelector, wantedExtension)) {
                            selector = manager.getExtensionEnabledCameraSelector(baseSelector, wantedExtension)
                            extensionActive = true
                        } else {
                            showStatus("${selectedScene} extension is not supported by this device; using image enhancement instead")
                        }
                    } catch (_: Exception) {
                        showStatus("${selectedScene} extension unavailable; using image enhancement instead")
                    }
                }
                val info = p.availableCameraInfos.firstOrNull { info ->
                    try { Camera2CameraInfo.from(info).getCameraCharacteristic(CameraCharacteristics.LENS_FACING) == lensFacing } catch (_: Exception) { false }
                } ?: p.availableCameraInfos.firstOrNull()
                if (info != null) {
                    supportedQualities = QualitySelector.getSupportedQualities(info).ifEmpty { listOf(Quality.HD) }
                    if (selectedQuality !in supportedQualities) selectedQuality = chooseDefaultQuality(supportedQualities)
                    photoSizes = try {
                        Camera2CameraInfo.from(info).getCameraCharacteristic(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                            ?.getOutputSizes(ImageFormat.JPEG)?.toList()?.sortedByDescending { it.width.toLong() * it.height.toLong() } ?: emptyList()
                    } catch (_: Exception) { emptyList() }
                    selectedPhotoSize?.let { if (it !in photoSizes) selectedPhotoSize = null }
                    photoResolutionButton.text = selectedPhotoSize?.let { "${it.width}×${it.height}" } ?: "PHOTO MAX"
                    supportedFps = readFpsRanges(info)
                    if (selectedFps !in supportedFps) {
                        selectedFps = when { 30 in supportedFps -> 30; supportedFps.isNotEmpty() -> supportedFps.minByOrNull { kotlin.math.abs(it - 30) } ?: 30; else -> 30 }
                    }
                    resolutionButton.text = "${qualityLabel(selectedQuality)}"
                    fpsButton.text = "${selectedFps} FPS"
                }
                val previewBuilder = Preview.Builder()
                val range = bestFpsRange(info, selectedFps)
                if (range != null) Camera2Interop.Extender(previewBuilder).setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, range)
                val preview = previewBuilder.build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val imageBuilder = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).setFlashMode(flashMode)
                selectedPhotoSize?.let { imageBuilder.setTargetResolution(it) }
                imageCapture = imageBuilder.build()
                if (!extensionActive) {
                    val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(selectedQuality, FallbackStrategy.lowerQualityOrHigherThan(selectedQuality))).build()
                    val videoBuilder = VideoCapture.Builder(recorder)
                    if (range != null) Camera2Interop.Extender(videoBuilder).setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, range)
                    videoCapture = videoBuilder.build()
                } else {
                    videoCapture = null
                }
                p.unbindAll()
                camera = if (videoCapture != null) p.bindToLifecycle(this, selector, preview, imageCapture, videoCapture)
                    else p.bindToLifecycle(this, selector, preview, imageCapture)
                cameraReady = true
                val extensionLabel = if (extensionActive) " · ${selectedScene} extension active" else if (selectedScene == "PORTRAIT" || selectedScene == "NIGHT") " · software fallback" else ""
                showStatus("Ready · ${qualityLabel(selectedQuality)} video · ${selectedFps} FPS · Auto sensor photo$extensionLabel")
            } catch (e: Exception) {
                cameraReady = false
                showStatus("Camera unavailable: ${e.localizedMessage ?: "unsupported configuration"}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // Auto starts at a stable, widely supported profile. Higher qualities remain selectable.
    private fun chooseDefaultQuality(list: List<Quality>): Quality = when {
        Quality.FHD in list -> Quality.FHD
        Quality.HD in list -> Quality.HD
        Quality.UHD in list -> Quality.UHD
        else -> Quality.SD
    }

    private fun readFpsRanges(info: androidx.camera.core.CameraInfo?): List<Int> {
        if (info == null) return listOf(30)
        return try {
            val ranges = Camera2CameraInfo.from(info).getCameraCharacteristic(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            ranges?.flatMap { listOf(it.lower, it.upper) }?.filter { it in 15..240 }?.distinct()?.sorted() ?: listOf(30)
        } catch (_: Exception) { listOf(30) }
    }

    private fun bestFpsRange(info: androidx.camera.core.CameraInfo?, fps: Int): Range<Int>? {
        if (info == null) return null
        return try {
            val ranges = Camera2CameraInfo.from(info).getCameraCharacteristic(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: return null
            ranges.filter { it.lower <= fps && it.upper >= fps }.minByOrNull { it.upper - it.lower }
        } catch (_: Exception) { null }
    }

    private fun showQualityPicker() {
        val labels = supportedQualities.map { qualityLabel(it) }.toTypedArray()
        val selected = supportedQualities.indexOf(selectedQuality).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Video resolution · supported by this camera")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                val candidate = supportedQualities[which]
                selectedQuality = candidate
                resolutionButton.text = qualityLabel(candidate)
                dialog.dismiss()
                startCamera()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showPhotoSizePicker() {
        if (photoSizes.isEmpty()) { showStatus("Photo sizes could not be read from this camera"); return }
        val labels = (listOf("Auto · maximum sensor output") + photoSizes.map { size ->
            val mp = size.width.toLong() * size.height.toLong() / 1_000_000.0
            val tag = when {
                size.width >= 3800 -> "4K class"
                size.width >= 2500 -> "2K class"
                size.width >= 1900 -> "1080p class"
                else -> ""
            }
            "${size.width} × ${size.height} · ${String.format("%.1f", mp)} MP ${if (tag.isNotEmpty()) "· $tag" else ""}"
        }).toTypedArray()
        val current = if (selectedPhotoSize == null) 0 else photoSizes.indexOf(selectedPhotoSize).let { if (it < 0) 0 else it + 1 }
        AlertDialog.Builder(this).setTitle("Photo resolution · hardware output sizes")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                selectedPhotoSize = if (which == 0) null else photoSizes[which - 1]
                photoResolutionButton.text = selectedPhotoSize?.let { "${it.width}×${it.height}" } ?: "PHOTO MAX"
                dialog.dismiss()
                startCamera()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showFpsPicker() {
        val choices = listOf(24, 30, 60, 120, 240)
        val labels = (listOf("Auto (recommended)") + choices.map { fps ->
            if (fps in supportedFps) "$fps FPS · supported" else "$fps FPS · not supported"
        }).toTypedArray()
        AlertDialog.Builder(this).setTitle("Frame rate · hardware supported")
            .setItems(labels) { dialog, which ->
                if (which == 0) selectedFps = if (30 in supportedFps) 30 else supportedFps.firstOrNull() ?: 30
                else {
                    val wanted = choices[which - 1]
                    if (wanted !in supportedFps) { showStatus("${wanted} FPS is not supported by this camera. Available: ${supportedFps.joinToString()}"); return@setItems }
                    selectedFps = wanted
                }
                fpsButton.text = "${selectedFps} FPS"
                dialog.dismiss()
                startCamera()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showSettings() {
        val items = arrayOf("Pro exposure compensation", "Device capability report", "Photo watermark: Pro Camera Elite", "Open Android app settings")
        AlertDialog.Builder(this).setTitle("Camera settings").setItems(items) { _, which ->
            when (which) {
                0 -> showExposureControl()
                1 -> showStatus("Video: ${supportedQualities.joinToString { qualityLabel(it) }} · FPS: ${supportedFps.joinToString()} · JPEG sizes: ${photoSizes.size} · photo auto: maximum sensor output")
                2 -> showStatus("Watermark is applied to saved photos")
                3 -> startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }.show()
    }

    private fun showExposureControl() {
        val activeCamera = camera ?: run { showStatus("Camera is not ready"); return }
        val state = activeCamera.cameraInfo.exposureState
        val range = state.exposureCompensationRange
        if (range.lower == 0 && range.upper == 0) { showStatus("Exposure compensation is not supported by this camera"); return }
        val bar = SeekBar(this).apply {
            max = range.upper - range.lower
            progress = (state.exposureCompensationIndex - range.lower).coerceIn(0, max)
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 12, 28, 4)
            addView(TextView(this@MainActivity).apply { text = "Exposure compensation · ${range.lower} to ${range.upper}"; setTextColor(0xFFFFFFFF.toInt()) })
            addView(bar)
        }
        val dialog = AlertDialog.Builder(this).setTitle("PRO · Exposure")
            .setView(container).setPositiveButton("Done", null).setNegativeButton("Reset") { _, _ -> activeCamera.cameraControl.setExposureCompensationIndex(0) }.create()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) activeCamera.cameraControl.setExposureCompensationIndex(range.lower + progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        dialog.show()
    }

    private fun takePhoto() {
        val capture = imageCapture ?: run { showStatus("Camera is not ready"); return }
        val sceneAtCapture = selectedScene
        shutter.animate().scaleX(0.88f).scaleY(0.88f).setDuration(75).withEndAction {
            shutter.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
        }.start()
        val temp = File(cacheDir, "capture_${System.currentTimeMillis()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(temp).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onError(exception: ImageCaptureException) { showStatus("Photo failed: ${exception.message}") }
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                shutterSound.play(MediaActionSound.SHUTTER_CLICK)
                shutter.performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM)
                cameraExecutor.execute {
                    try {
                        val source = BitmapFactory.decodeFile(temp.absolutePath) ?: throw IllegalStateException("Could not decode captured photo")
                        val mutable = applySceneLook(source, sceneAtCapture)
                        val canvas = Canvas(mutable)
                        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.WHITE
                            textSize = (mutable.width * 0.026f).coerceIn(22f, 54f)
                            textAlign = Paint.Align.RIGHT
                            setShadowLayer(4f, 1f, 2f, android.graphics.Color.BLACK)
                        }
                        val pad = mutable.width * 0.035f
                        canvas.drawText("Pro Camera Elite", mutable.width - pad, mutable.height - pad, paint)
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "PCE_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/Camera")
                        }
                        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("Gallery insert failed")
                        contentResolver.openOutputStream(uri)?.use { out -> mutable.compress(Bitmap.CompressFormat.JPEG, 96, out) }
                        mutable.recycle(); temp.delete()
                        runOnUiThread { showStatus("Photo saved to Gallery · Pro Camera Elite watermark applied") }
                    } catch (e: Exception) { runOnUiThread { showStatus("Save failed: ${e.localizedMessage}") } }
                }
            }
        })
    }

    private fun applySceneLook(source: Bitmap, scene: String): Bitmap {
        val matrix = ColorMatrix()
        when (scene) {
            "FOOD" -> matrix.set(floatArrayOf(1.10f,0f,0f,0f,5f, 0f,1.04f,0f,0f,2f, 0f,0f,0.91f,0f,0f, 0f,0f,0f,1f,0f))
            "FOREST" -> matrix.set(floatArrayOf(0.96f,0f,0f,0f,0f, 0f,1.12f,0f,0f,3f, 0f,0f,0.94f,0f,0f, 0f,0f,0f,1f,0f))
            "NIGHT" -> matrix.set(floatArrayOf(1.12f,0f,0f,0f,10f, 0f,1.12f,0f,0f,10f, 0f,0f,1.12f,0f,10f, 0f,0f,0f,1f,0f))
            "SUPER MOON" -> { matrix.setSaturation(0.72f); val contrast = ColorMatrix(floatArrayOf(1.16f,0f,0f,0f,-12f, 0f,1.16f,0f,0f,-12f, 0f,0f,1.16f,0f,-12f, 0f,0f,0f,1f,0f)); matrix.postConcat(contrast) }
            "UNDERWATER" -> matrix.set(floatArrayOf(1.18f,0f,0f,0f,5f, 0f,1.04f,0f,0f,2f, 0f,0f,0.82f,0f,0f, 0f,0f,0f,1f,0f))
            "SUPERNOVA" -> { matrix.setSaturation(1.42f); val tint = ColorMatrix(floatArrayOf(1.06f,0f,0f,0f,2f, 0f,0.98f,0f,0f,0f, 0f,0f,1.12f,0f,4f, 0f,0f,0f,1f,0f)); matrix.postConcat(tint) }
            "MONO" -> matrix.setSaturation(0f)
            "SEPIA" -> matrix.set(floatArrayOf(0.393f,0.769f,0.189f,0f,0f, 0.349f,0.686f,0.168f,0f,0f, 0.272f,0.534f,0.131f,0f,0f, 0f,0f,0f,1f,0f))
            "PORTRAIT" -> matrix.setSaturation(1.08f)
            else -> return source
        }
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(matrix) }
        canvas.drawBitmap(source, 0f, 0f, paint)
        source.recycle()
        return output
    }

    private fun toggleVideo() {
        val active = recording
        if (active != null) { active.stop(); recording = null; shutter.setImageResource(R.drawable.shutter_core); return }
        val capture = videoCapture ?: run { showStatus("Video camera is not ready"); return }
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "PCE_VIDEO_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "DCIM/Camera")
        }
        val output = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(values).build()
        var pending = capture.output.prepareRecording(this, output)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) pending = pending.withAudioEnabled()
        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> { showStatus("Recording · ${qualityLabel(selectedQuality)} · ${selectedFps} FPS"); shutter.setImageResource(android.R.drawable.presence_video_busy) }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    shutter.setImageResource(R.drawable.shutter_core)
                    showStatus(if (event.hasError()) "Video save error: ${event.error}" else "Video saved to Gallery")
                }
            }
        }
    }

    private fun qualityLabel(q: Quality): String = when (q) { Quality.UHD -> "4K UHD"; Quality.FHD -> "1080p"; Quality.HD -> "720p"; else -> "SD" }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(intent) } catch (_: Exception) { showStatus("No Gallery app found") }
    }

    private fun showStatus(message: String) { status.text = message }

    override fun onDestroy() {
        recording?.stop()
        cameraExecutor.shutdown()
        shutterSound.release()
        super.onDestroy()
    }
}
