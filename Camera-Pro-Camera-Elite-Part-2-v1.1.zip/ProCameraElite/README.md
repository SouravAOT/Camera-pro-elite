# Camera Pro Elite

Native Android CameraX application. The launcher name is **Camera Pro Elite**. Still photos are saved through MediaStore to `DCIM/Camera` with the Pro Camera Elite watermark.

## Main camera screen

The primary camera tabs are **PHOTO**, **PORTRAIT**, **VIDEO** and **PRO**. Additional looks are kept in the separate **MODE** selector. Resolution, photo size and FPS controls are tucked into the animated three-dot menu rather than permanently occupying the top of the viewfinder.

## Working camera features

- CameraX live preview, front/back camera switching, tap-to-focus/AE metering and pinch zoom.
- Still capture at the camera's selected/default maximum JPEG output size.
- Flash auto/on/off, shutter sound and haptic capture confirmation.
- Video recording with audio when permission is granted.
- Camera-reported video quality and FPS choices; unsupported values are rejected with a status message.
- PRO exposure compensation using the active camera's advertised range.
- FOOD, FOREST, NIGHT fallback, SUPER MOON, UNDERWATER, SUPERNOVA, MONO and SEPIA apply real colour processing to the saved JPEG.
- PORTRAIT and NIGHT use CameraX BOKEH/NIGHT extensions when the device reports support.

## Device-specific limitations

Camera extensions depend on the phone's camera vendor and hardware. If BOKEH is unavailable, PORTRAIT falls back to a colour treatment and does not claim subject-aware background blur. If NIGHT extension is unavailable, NIGHT applies post-capture low-light tuning; it is not multi-frame computational night photography. PRO currently provides exposure compensation, tap focus/AE and zoom, not manual ISO/shutter/white balance/focus distance. Slow motion and time-lapse are not presented as available modes in this revision.

A higher resolution or FPS cannot be forced when the sensor/encoder does not advertise it. CameraX quality presets do not provide a universal 1440p/2K tier. Device testing is required to confirm each advertised combination.

## Build

```bash
./gradlew --no-daemon assembleDebug
```

GitHub Actions workflow: `.github/workflows/build-pro-camera-elite.yml`. It installs Android SDK platform 35 and Build Tools 35.0.0, then builds the debug APK.

## Reference archives

Original user-supplied reference ZIPs, including `CameraX-main.zip` and the approved `Premium-PRO-Camera-Icon.png`, remain under `reference-assets/` for traceability. They are not blindly merged into the APK; some contain unrelated sample-catalog assets and independent sample modules.
