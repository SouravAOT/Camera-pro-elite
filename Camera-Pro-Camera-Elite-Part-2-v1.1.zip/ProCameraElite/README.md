# Camera — Pro Camera Elite

A native Android camera application project. The launcher/app name is **Camera**. Still photos receive the **Pro Camera Elite** watermark in the lower-right corner and are saved to `DCIM/Camera`.

## Project facts

- Native Android Activity + CameraX (Preview, ImageCapture, VideoCapture); no WebView.
- Java 17 toolchain, Gradle 8.9 wrapper, Android Gradle Plugin 8.7.3, Kotlin 2.0.21.
- `app/src/main/res/layout/main.xml` is the direct-open camera viewfinder layout.
- Camera permission is requested on first launch. The app opens directly into the camera after permission is granted.
- Photo capture uses the camera's selected/default maximum sensor output. Video quality choices are enumerated from the active camera's CameraX-supported qualities.
- FPS ranges are queried from Camera2 characteristics. Auto prefers a supported 30 FPS range; manual choices are limited to values advertised by the active camera. The selected range is applied to CameraX preview and video use-case requests; the device encoder may still constrain the final recording rate.
- Photo/video files are written through MediaStore to `DCIM/Camera`.

## Build

```bash
./gradlew --no-daemon assembleDebug
```

Open the root folder in Android Studio or push it to GitHub. GitHub Actions is configured in `.github/workflows/build-pro-camera-elite.yml` and uploads the debug APK after a successful build.

## Device capability and quality policy

4K UHD is offered only when CameraX reports UHD support for the active camera. FHD/HD/SD are offered only when reported. CameraX's standard quality presets do not expose a universal standalone 1440p/2K preset; this baseline therefore does not claim 2K support unless a later Camera2 recording path explicitly adds and verifies that exact output size. The app never upscales a lower-resolution recording and labels the actual selected quality. Photo capture requests maximum-quality still capture; the exact sensor output size remains hardware/CameraX-selected. The FPS menu only offers values advertised by the active camera's AE target FPS ranges. A device may support a given frame rate at one resolution but not another; CameraX/encoder constraints can still reject a combination. If binding fails, the status message reports the failure rather than pretending the setting worked.

## Current implementation scope (read before publishing)

Implemented in this source baseline:
- Live camera preview; front/back switching; tap-to-focus/exposure metering.
- Still capture, lower-right Pro Camera Elite watermark, MediaStore save.
- Video recording with audio when permission is granted; MediaStore save.
- Camera-reported video quality and FPS menus; device-dependent defaults.
- Flash auto/on/off; scene/mode strip; gallery hand-off.

Not yet implemented as production-grade imaging pipelines:
- Live Photo as a single interoperable motion-photo file (the UI explicitly warns that it is not exported as one file).
- OEM CameraX Night/Bokeh/HDR/Face Retouch extensions, true underwater processing, moon enhancement, supernova/forest/food computational profiles, or actual optical zoom lens selection. Scene labels are selection/UI only until their corresponding supported imaging pipeline is integrated.
- Full manual ISO/shutter/white-balance/focus-distance controls, RAW/DNG, QR scanning, stabilization/HDR capture toggles, high-speed slow motion/time-lapse pipelines, video watermarking, and in-app gallery browser.
- Resolution/FPS combination matrix testing across physical devices. FPS is applied to the preview request; device encoders may independently constrain recording output.

These items are intentionally not represented as completed controls. They require device testing and feature-specific implementation rather than cosmetic buttons.

## Reference ZIPs supplied for this project

The original ZIPs are preserved under `reference-assets/` for review and traceability. They are not blindly unpacked into the APK: some contain sample-catalog material unrelated to a camera app, duplicate/zero-byte entries, or independent sample modules that need dependency and license review before integration.

## GitHub Actions

Push this folder to a repository root. The workflow builds `assembleDebug` on GitHub Actions and stores the APK as an artifact. A green workflow is the build verification; a local source ZIP alone is not proof that every phone's camera configuration is supported.
